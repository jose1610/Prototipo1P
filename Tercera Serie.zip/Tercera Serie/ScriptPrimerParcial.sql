-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema PrimerParcial
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema PrimerParcial
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `PrimerParcial` DEFAULT CHARACTER SET utf8 ;
USE `PrimerParcial` ;

-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_puesto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_puesto` (
  `pk_id_puesto` INT NOT NULL AUTO_INCREMENT,
  `nombre_puesto` VARCHAR(45) NULL,
  PRIMARY KEY (`pk_id_puesto`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_empleado`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_empleado` (
  `pk_id_emp` INT NOT NULL AUTO_INCREMENT,
  `nombre_emp` VARCHAR(45) NULL,
  `apellido emp` VARCHAR(45) NULL,
  `dpi_emp` INT NULL,
  `fecha_nac` DATE NULL,
  `fk_id_puesto` INT NOT NULL,
  PRIMARY KEY (`pk_id_emp`, `fk_id_puesto`),
  INDEX `fk_tbl_empleado_tbl_puesto_idx` (`fk_id_puesto` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_empleado_tbl_puesto`
    FOREIGN KEY (`fk_id_puesto`)
    REFERENCES `PrimerParcial`.`tbl_puesto` (`pk_id_puesto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_producto` (
  `pk_id_producto` INT NOT NULL AUTO_INCREMENT,
  `nombre_producto` VARCHAR(45) NULL,
  `precio` FLOAT NULL,
  PRIMARY KEY (`pk_id_producto`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_bodega`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_bodega` (
  `pk_id_bodega` INT NOT NULL AUTO_INCREMENT,
  `direccion_bodega` VARCHAR(45) NULL,
  `nombre_bodega` VARCHAR(45) NULL,
  PRIMARY KEY (`pk_id_bodega`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_inventario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_inventario` (
  `pk_id_inventario` INT NOT NULL AUTO_INCREMENT,
  `cantidad` INT NULL,
  `fk_id_bodega` INT NOT NULL,
  `fk_id_producto` INT NOT NULL,
  PRIMARY KEY (`pk_id_inventario`, `fk_id_bodega`, `fk_id_producto`),
  INDEX `fk_tbl_inventario_tbl_bodega1_idx` (`fk_id_bodega` ASC) VISIBLE,
  INDEX `fk_tbl_inventario_tbl_producto1_idx` (`fk_id_producto` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_inventario_tbl_bodega1`
    FOREIGN KEY (`fk_id_bodega`)
    REFERENCES `PrimerParcial`.`tbl_bodega` (`pk_id_bodega`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_inventario_tbl_producto1`
    FOREIGN KEY (`fk_id_producto`)
    REFERENCES `PrimerParcial`.`tbl_producto` (`pk_id_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_empleado_bodega`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_empleado_bodega` (
  `fk_id_empleado` INT NOT NULL,
  `fk_id_bodega` INT NOT NULL,
  PRIMARY KEY (`fk_id_empleado`, `fk_id_bodega`),
  INDEX `fk_tbl_empleado_bodega_tbl_bodega1_idx` (`fk_id_bodega` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_empleado_bodega_tbl_empleado1`
    FOREIGN KEY (`fk_id_empleado`)
    REFERENCES `PrimerParcial`.`tbl_empleado` (`pk_id_emp`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_empleado_bodega_tbl_bodega1`
    FOREIGN KEY (`fk_id_bodega`)
    REFERENCES `PrimerParcial`.`tbl_bodega` (`pk_id_bodega`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_proveedor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_proveedor` (
  `pk_id_proveedor` INT NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` VARCHAR(45) NULL,
  `direccion_proveedor` VARCHAR(45) NULL,
  PRIMARY KEY (`pk_id_proveedor`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_cliente` (
  `pk_id_cliente` INT NOT NULL AUTO_INCREMENT,
  `nombre_cliente` VARCHAR(45) NULL,
  `apellido_cliente` VARCHAR(45) NULL,
  `nit_cliente` INT NULL,
  PRIMARY KEY (`pk_id_cliente`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_pedido`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_pedido` (
  `pk_id_pedido` INT NOT NULL AUTO_INCREMENT,
  `cantidad` INT NULL,
  `fk_id_producto` INT NOT NULL,
  `fk_id_empleado` INT NOT NULL,
  `fk_id_puesto` INT NOT NULL,
  PRIMARY KEY (`pk_id_pedido`, `fk_id_producto`, `fk_id_empleado`, `fk_id_puesto`),
  INDEX `fk_tbl_pedido_tbl_producto1_idx` (`fk_id_producto` ASC) VISIBLE,
  INDEX `fk_tbl_pedido_tbl_empleado1_idx` (`fk_id_empleado` ASC, `fk_id_puesto` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_pedido_tbl_producto1`
    FOREIGN KEY (`fk_id_producto`)
    REFERENCES `PrimerParcial`.`tbl_producto` (`pk_id_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_pedido_tbl_empleado1`
    FOREIGN KEY (`fk_id_empleado` , `fk_id_puesto`)
    REFERENCES `PrimerParcial`.`tbl_empleado` (`pk_id_emp` , `fk_id_puesto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_cuotas_pago`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_cuotas_pago` (
  `pk_id_cuotas` INT NOT NULL AUTO_INCREMENT,
  `numero_cuotas` INT NULL,
  PRIMARY KEY (`pk_id_cuotas`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_tipo_pago`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_tipo_pago` (
  `pk_id_tipo_pago` INT NOT NULL AUTO_INCREMENT,
  `nombre_tipo` VARCHAR(45) NULL,
  `fk_id_cuotas` INT NOT NULL,
  PRIMARY KEY (`pk_id_tipo_pago`, `fk_id_cuotas`),
  INDEX `fk_tbl_tipo_pago_tbl_cuotas_pago1_idx` (`fk_id_cuotas` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_tipo_pago_tbl_cuotas_pago1`
    FOREIGN KEY (`fk_id_cuotas`)
    REFERENCES `PrimerParcial`.`tbl_cuotas_pago` (`pk_id_cuotas`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_factura`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_factura` (
  `pk_id_factura` INT NOT NULL AUTO_INCREMENT,
  `serie_factura` VARCHAR(45) NULL,
  `fk_id_cliente` INT NOT NULL,
  `fk_id_pedido` INT NOT NULL,
  `fk_id_producto` INT NOT NULL,
  `fk_id_empleado` INT NOT NULL,
  `fk_id_puesto` INT NOT NULL,
  `fk_id_tipo_pago` INT NOT NULL,
  `fk_id_cuotas` INT NOT NULL,
  PRIMARY KEY (`pk_id_factura`, `fk_id_cliente`, `fk_id_pedido`, `fk_id_producto`, `fk_id_empleado`, `fk_id_puesto`, `fk_id_tipo_pago`, `fk_id_cuotas`),
  INDEX `fk_tbl_factura_tbl_cliente1_idx` (`fk_id_cliente` ASC) VISIBLE,
  INDEX `fk_tbl_factura_tbl_pedido1_idx` (`fk_id_pedido` ASC, `fk_id_producto` ASC, `fk_id_empleado` ASC, `fk_id_puesto` ASC) VISIBLE,
  INDEX `fk_tbl_factura_tbl_tipo_pago1_idx` (`fk_id_tipo_pago` ASC, `fk_id_cuotas` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_factura_tbl_cliente1`
    FOREIGN KEY (`fk_id_cliente`)
    REFERENCES `PrimerParcial`.`tbl_cliente` (`pk_id_cliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_factura_tbl_pedido1`
    FOREIGN KEY (`fk_id_pedido` , `fk_id_producto` , `fk_id_empleado` , `fk_id_puesto`)
    REFERENCES `PrimerParcial`.`tbl_pedido` (`pk_id_pedido` , `fk_id_producto` , `fk_id_empleado` , `fk_id_puesto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_factura_tbl_tipo_pago1`
    FOREIGN KEY (`fk_id_tipo_pago` , `fk_id_cuotas`)
    REFERENCES `PrimerParcial`.`tbl_tipo_pago` (`pk_id_tipo_pago` , `fk_id_cuotas`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_ventas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_ventas` (
  `id_venta` INT NOT NULL AUTO_INCREMENT,
  `fecha_venta` DATE NULL,
  `fk_id_factura` INT NOT NULL,
  `total_venta` INT NULL,
  `fk_id_empleado` INT NOT NULL,
  PRIMARY KEY (`id_venta`, `fk_id_factura`, `fk_id_empleado`),
  INDEX `fk_tbl_ventas_tbl_factura1_idx` (`fk_id_factura` ASC) VISIBLE,
  INDEX `fk_tbl_ventas_tbl_empleado1_idx` (`fk_id_empleado` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_ventas_tbl_factura1`
    FOREIGN KEY (`fk_id_factura`)
    REFERENCES `PrimerParcial`.`tbl_factura` (`pk_id_factura`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_ventas_tbl_empleado1`
    FOREIGN KEY (`fk_id_empleado`)
    REFERENCES `PrimerParcial`.`tbl_empleado` (`pk_id_emp`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_compra`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_compra` (
  `pk_id_compra` INT NOT NULL AUTO_INCREMENT,
  `fecha_compra` DATE NULL,
  `cantidad` INT NULL,
  `tbl_empleado_pk_id_emp` INT NOT NULL,
  `tbl_empleado_fk_id_puesto` INT NOT NULL,
  `tbl_producto_pk_id_producto` INT NOT NULL,
  PRIMARY KEY (`pk_id_compra`, `tbl_empleado_pk_id_emp`, `tbl_empleado_fk_id_puesto`, `tbl_producto_pk_id_producto`),
  INDEX `fk_tbl_compra_tbl_empleado1_idx` (`tbl_empleado_pk_id_emp` ASC, `tbl_empleado_fk_id_puesto` ASC) VISIBLE,
  INDEX `fk_tbl_compra_tbl_producto1_idx` (`tbl_producto_pk_id_producto` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_compra_tbl_empleado1`
    FOREIGN KEY (`tbl_empleado_pk_id_emp` , `tbl_empleado_fk_id_puesto`)
    REFERENCES `PrimerParcial`.`tbl_empleado` (`pk_id_emp` , `fk_id_puesto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_compra_tbl_producto1`
    FOREIGN KEY (`tbl_producto_pk_id_producto`)
    REFERENCES `PrimerParcial`.`tbl_producto` (`pk_id_producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_comprobante`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_comprobante` (
  `fk_id_proveedor` INT NOT NULL,
  `fk_id_compra` INT NOT NULL,
  PRIMARY KEY (`fk_id_proveedor`, `fk_id_compra`),
  INDEX `fk_tbl_comprobante_tbl_compra1_idx` (`fk_id_compra` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_comprobante_tbl_proveedor1`
    FOREIGN KEY (`fk_id_proveedor`)
    REFERENCES `PrimerParcial`.`tbl_proveedor` (`pk_id_proveedor`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_comprobante_tbl_compra1`
    FOREIGN KEY (`fk_id_compra`)
    REFERENCES `PrimerParcial`.`tbl_compra` (`pk_id_compra`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_comisiones`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_comisiones` (
  `fk_id_venta` INT NOT NULL,
  `fk_id_empleado` INT NOT NULL,
  `fk_id_puesto` INT NOT NULL,
  `porcentaje` FLOAT NULL,
  PRIMARY KEY (`fk_id_venta`, `fk_id_empleado`, `fk_id_puesto`),
  INDEX `fk_tbl_comisiones_tbl_empleado1_idx` (`fk_id_empleado` ASC, `fk_id_puesto` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_comisiones_tbl_ventas1`
    FOREIGN KEY (`fk_id_venta`)
    REFERENCES `PrimerParcial`.`tbl_ventas` (`id_venta`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_comisiones_tbl_empleado1`
    FOREIGN KEY (`fk_id_empleado` , `fk_id_puesto`)
    REFERENCES `PrimerParcial`.`tbl_empleado` (`pk_id_emp` , `fk_id_puesto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_zona_destino`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_zona_destino` (
  `id_zona_destino` INT NOT NULL AUTO_INCREMENT,
  `nombre_zona` VARCHAR(45) NULL,
  `fk_id_empleado` INT NOT NULL,
  `fk_id_puesto` INT NOT NULL,
  PRIMARY KEY (`id_zona_destino`, `fk_id_empleado`, `fk_id_puesto`),
  INDEX `fk_tbl_zona_destino_tbl_empleado1_idx` (`fk_id_empleado` ASC, `fk_id_puesto` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_zona_destino_tbl_empleado1`
    FOREIGN KEY (`fk_id_empleado` , `fk_id_puesto`)
    REFERENCES `PrimerParcial`.`tbl_empleado` (`pk_id_emp` , `fk_id_puesto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `PrimerParcial`.`tbl_entrega`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `PrimerParcial`.`tbl_entrega` (
  `fk_id_zona_destino` INT NOT NULL,
  `fk_id_factura` INT NOT NULL,
  PRIMARY KEY (`fk_id_zona_destino`, `fk_id_factura`),
  INDEX `fk_tbl_entrega_tbl_factura1_idx` (`fk_id_factura` ASC) VISIBLE,
  CONSTRAINT `fk_tbl_entrega_tbl_zona_destino1`
    FOREIGN KEY (`fk_id_zona_destino`)
    REFERENCES `PrimerParcial`.`tbl_zona_destino` (`id_zona_destino`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_tbl_entrega_tbl_factura1`
    FOREIGN KEY (`fk_id_factura`)
    REFERENCES `PrimerParcial`.`tbl_factura` (`pk_id_factura`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
